<!DOCTYPE html>
<html>

  <head>
    <meta charset="UTF-8">
    <title>ASCII Slot Machine - OOP PHP Project</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:400,500" type="text/css">
  </head>

  <body>

    <h1>Welcome</h1>
    <p>Click the button for your starting credits:
    <br/>
    <form action="" method="post">
    <input type="hidden" name="action" value="submit" />
    <input id="submit" type="submit" name="submit" value="submit">
    </form>

    </p>
    <?php
    if (isset($_POST['action'])){
    header("Location: machine.php");
    exit;
    }
    ?>

  </body>

</html>
