<?php

// OOP PHP Slots
// TESTING
$randomA1 = "%";
$randomA2 = "$";
$randomA3 = "*";
$randomB1 = "#";
$randomB2 = "$";
$randomB3 = "~";
$randomC1 = "*";
$randomC2 = "$";
$randomC3 = "&";
$message = "You have won ";
$amount = "250 Credits!";

?>

<!DOCTYPE html>
<html>

  <head>
    <meta charset="UTF-8">
    <title>OOP PHP Slots</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:400,500" type="text/css">
  </head>

  <body>

    <h1>Proof of concept</h1>
    <p>How many credits would you like to wager?
    <br/><form>
      <input type="text" size="20" name="credits"><span class="credits"> Credits</span>
    </form>
    </p>
    <div class="blah">
      &nbsp;&nbsp;&nbsp;[ = = = ]&nbsp;&nbsp;<a href="#">0</a>
      <br/>&nbsp;&nbsp;&nbsp;[<?php echo " " . $randomA1 . " " . $randomB1 . " " . $randomC1 . " "; ?> ]&nbsp;&nbsp;<a href="#">|</a>
      <span id="results"><br/>> [<?php echo " " . $randomA2 . " " . $randomB2 . " " . $randomC2 . " "; ?> ]</span>&nbsp;&nbsp;<a href="#">|</a>
      <br/>&nbsp;&nbsp;&nbsp;[<?php echo " " . $randomA3 . " " . $randomB3 . " " . $randomC3 . " "; ?> ]]]<a href="#">]</a>
      <br/>&nbsp;&nbsp;&nbsp;[ = = = ]
    </div>

    <!-- <p class="credits"><?php echo $message . " " . $amount; ?></p> -->

  </body>

</html>
