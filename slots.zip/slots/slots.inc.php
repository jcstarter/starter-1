<?php

// Hello World
class ClassName {

  // Properties
  // Functions

}

?>
