<?php

class Calc {

  public $calc;
  public $num1;
  public $num2;


  public function __construct($calc, $num1, $num2){
    $this->calc = $calc;
    $this->num1 = $num1;
    $this->num2 = $num2;
  }

  public function calcMethod(){

    switch ($this->calc) {
      case 'add':
        $result = $this->num1 + $this->num2;
        break;
      case 'sub':
        $result = $this->num1 - $this->num2;
        break;
      case 'mult':
        $result = $this->num1 * $this->num2;
        break;

      default:
        $result = "Error";
        break;
    }

    return $result;

  }

}

?>
