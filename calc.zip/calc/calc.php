<?php
 include "calculation.inc.php";

// this is the results page I think


$calc = $_POST["calc"];
$num1 = $_POST["num1"];
$num2 = $_POST["num2"];

$calculator = new Calc($calc, $num1, $num2);

?>

<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8">
    <title>Simple OOP PHP Calc</title>
  </head>
  <body>

<h1>Simple Calc</h1>
Select Arithmetic:<br />
<form action="calc.php" method="POST">

      <select name="calc">
        <option value="add">Add</option>
        <option value="sub">Subtract</option>
        <option value="mult">Multiply</option>
      </select><br />

      <p>First Number:<br />
      <input type="text" name="num1"><br /></p>

      <p>Second Number:<br />
      <input type="text" name="num2"><br /></p>

      <input type="submit" value= "Submit">

</form><br />
<?php
  echo "--------------------<br />";
  echo "<strong>Result:</strong><br />" . $calculator->calcMethod();
  echo "<br />--------------------";
?>
  </body>
</html>
