<!DOCTYPE html>
<html>

  <head>
    <meta charset="UTF-8">
    <title>ASCII Slot Machine - OOP PHP Project</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:400,500" type="text/css">
  </head>

  <body>

    <h1>Welcome</h1>
    <p>Click the button for your starting credits:
    <br/>
    <form action="machine.php" method="post">
    <input type="submit" name="submit" value="Generate Credits">
    </form>

    </p>


  </body>

</html>
